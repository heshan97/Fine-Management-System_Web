<!-- Modal for payment -->
<div class="modal fade" id="messageBox" tabindex="-1">
  <div class="modal-dialog bg-dark modal-dialog-centered">
    <div class="modal-content bg-dark" style="border: none;">
      <div class="modal-header text-center" >
        <h4 class="modal-title text-light" id="messageTitle">Payment Details</h4>
        <button type="button" class="btn text-light" data-bs-dismiss="modal"> <i class="fas fa-times fs-5"></i></button>
      
      </div>
      <div id="messageBody" class="modal-body">
        <form action="https://sandbox.payhere.lk/pay/checkout" class="text-light" method="post">
          <input type="hidden" name="merchant_id" value="1217251"> <!-- Replace your Merchant ID -->
          <input type="hidden" name="return_url" value="https://payherewebapp.000webhostapp.com">
          <input type="hidden" name="cancel_url" value="">
          <input type="hidden" name="notify_url" value="https://payherewebapp.000webhostapp.com/notify.php">
          <input type="text" name="order_id" value="ItemNo12345">
          <input type="text" name="items" value="Door bell wireless"><br>
          <input type="text" name="currency" value="LKR">
          <input type="text" name="amount" value="1000">  
          <div class="form-group mb-2">
            <label for="name" class="mb-2 texl">Name</label>
            <input type="text" class="form-control  bg-dark text-light" id="name" value="Lasith">
          </div>
          <div class="form-group mb-2">
            <label for="nic" class="mb-2">NIC</label>
            <input type="text" class="form-control  bg-dark text-light" id="nic" value="998566530V">
          </div>
          <div class="form-group mb-2">
            <label for="exampleInputPassword1" class="mb-2">Email</label>
            <input type="email" class="form-control  bg-dark text-light" id="exampleInputPassword1" value="lasith@gmail.com">
          </div>
          <div class="form-group mb-2">
            <label for="offences" class="mb-2">Offence(s)</label>
            <textarea class="form-control bg-dark text-light"  id="address" style="height: 100px">B16,Inamaluwa,Matara</textarea>
          </div>
          <div class="d-flex flex-row mb-2 fs-4">
            <div class="col">Penalty Amount: </div>
            <div class="col text-end">Rs: 5245.52</div>
            
          </div>          
            <button type="submit" class="mt-3 btn btn-primary col-12" data-bs-dismiss="modal">Proceed to Payment</button>
        
        </form>
      </div>

    </div>
  </div>
</div>
<button id="paymentModal" type="button" hidden="true" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#messageBox">
</button>


<!-- container div -->

<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand">
      <h1 class="pt-2 px-3">Fine Receipts</h1>
    </a>

  </div>
</nav>

<div class="d-flex container flex-column  bg-dark  text-white col-lg-11 h-auto " style="width: 95%;">
  <div class=" d-flex  col-10 flex-column">
    <div id="search_result" class="bg-dark">

    </div>
    <div class="d-flex flex-row col-12">

      <div class="col-1 ms-3 mt-3"> <img src="./images/glogo.png" height="75px" alt=""></div>
      <div class="col-8 text-center mt-4 ps-4">
        <span class="fw-bold "> SPOT FINE STATEMENT </span><br> Road Safety Act 1985</p>
      </div>
      <div class="col-1 me-2 mt-3 "><img src="./images/policeLogo.png" alt=""></div>
    </div>

    <div class="d-flex flex-col  col-10   ms-3 mt-3">
      <div class="flex-row col">
        <div class="mb-3 fw-bold ">Fine Statement</div>

        <div id="statement_id" class="">Statement No: 56 <span id="statement_id"></span></div>
        <div class="">Officer ID: 56859 </div>
        <div class="">Driver NIC: <span id="driver_nic">990811130V</span></div>
        <div class="">Issue Date: <span id="issue_date">2021-11-20</span></div>
        <div class="">Issue Time: <span id="issue_time">13:23:00</span></div>
        <div class="">Street: Kaluthara Rd.</div>
      </div>
      <div class="flex-row col">
        <div class="mb-3 fw-bold">Offence(s)</div>
        <div class="">Offence(1): Driver is drunk and caugth while driving the vehicle <span id="rule"></span></div>
        <div class=""> <span id="description"></span> <br>
          Penalty : Rs.5625.23<span id="penalty"></span><br>
          Due Date : 2021-12-04 <span id="due_date"></span>
        </div>
      </div>
    </div>
    <div class="col-11 text-end">
      <button type="button" class="btn btn-primary col-3 mx-3 mt-4 mb-5" onclick="getData(50)"> Settle Fine Amount</button>
    </div>
  </div>
</div>
<script>
  const driver_nic = document.getElementById('driver_nic');
  const driver_name = document.getElementById('driver_name');
  const offences = document.getElementById('offences');
  const penalty = document.getElementById('penalty');
  const paymentModal = document.getElementById('paymentModal');
  
  //sends the fine receipt id to the database and retrive fine receipt info use for payment
  function getData(receipt_id) {
    const xhttp = new XMLHttpRequest();
    paymentModal.click();
    xhttp.onload = () => {
      //
    }
    xhttp.open('GET', "Fine_receipts/get_data.php?receipt_id='" + receipt_id);
    xhttp.send();
  }


</script>